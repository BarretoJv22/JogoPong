//variaveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let dBolinha = 15;
let rBolinha = dBolinha /2;

//velocidade da bolinha
let velXBolinha = 5;
let velYBolinha = 5;

// variaveis raquete
let xRaquete = 10;
let yRaquete = 150;
let larguraRaquete = 10;
let alturaRaquete = 100;

// variaveis raquete oponente

let xRaqOponente = 580;
let yRaqOponente = 150;
let larguraRaqOponente = 10;
let alturaRaqOponente = 100;
let velocidadeYOponente;

//placar do jogo
let meusPontos = 0;
let pontosOponente = 0;

//sons do jogo:
let raquetada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

//variavel para verificar se colidiu
let colidiu = false;

function setup() {
  createCanvas(600, 400);
  trilha.loop();
  
}

function draw() {
  background(0);
  mostraBolinha();
  movimentarBolinha();
  verificarBordas();
  mostrarRaquete(xRaquete, yRaquete);
  mostrarRaquete(xRaqOponente, yRaqOponente);
  movimentaRaquete();
  //verificaColisaoRaquete(); (antigo)
  verificaColisaoRaquete(xRaquete, yRaquete);
  verificaColisaoRaquete(xRaqOponente, yRaqOponente);
  //movimentarRaqOponente();
  incluiPlacar(meusPontos, pontosOponente);
  adicionarPontos();
  multiplayer();
  bolinhaNaoFicaPresa();
  
  function mostraBolinha(){
  circle(xBolinha, yBolinha, dBolinha);
}
  function movimentarBolinha(){
    xBolinha += velXBolinha;
  yBolinha += velYBolinha;
  }
  function verificarBordas(){
    if (xBolinha + rBolinha > width || xBolinha - rBolinha < 0){
    velXBolinha *= -1;
  }
  if (yBolinha + rBolinha > height || yBolinha - rBolinha <0){
    velYBolinha *= -1;
  }
  }
  function mostrarRaquete(x, y){
    rect(x, y, larguraRaquete, alturaRaquete);
  }
  
   
  function movimentaRaquete(){
    if (keyIsDown(UP_ARROW)){
      yRaquete -= 10;
    }if (keyIsDown(DOWN_ARROW)){
      yRaquete += 10;
    }
    
  }
  
  /*function verificaColisaoRaquete(){
    if(xBolinha - rBolinha < xRaquete + larguraRaquete && yBolinha - rBolinha < yRaquete + alturaRaquete && yBolinha + rBolinha > yRaquete){
      velXBolinha *= -1;
    }
  }*/
  
  function verificaColisaoRaquete(x, y){
    colidiu = collideRectCircle(x, y, larguraRaquete, alturaRaquete, xBolinha, yBolinha, rBolinha);
    if (colidiu){
      velXBolinha *= -1;
      raquetada.play();
    }
  }
  
  function movimentarRaqOponente(){
    velocidadeYOponente = yBolinha - yRaqOponente - larguraRaqOponente /2 - 100
    yRaqOponente += velocidadeYOponente
  }
  
  function adicionarPontos(){
    if(xBolinha + rBolinha > 599){
      meusPontos += 1;
      ponto.play();
      
    }
    if(xBolinha - rBolinha <1){
      pontosOponente +=1;
      ponto.play();
    }
  }
  function incluiPlacar(z,c){
    stroke(255);
    textAlign(CENTER);
    textSize(16);
    fill(color(255,165,0))
    rect(150, 10, 40, 20);
    fill(255)
    text(z, 170, 26)
    fill(color(255,165,0))
    rect(450, 10, 40, 20);
    fill(255)
    text(c, 470, 26)
  }
  
  function multiplayer(){
     if (keyIsDown(87)){
      yRaqOponente -= 10;
    }if (keyIsDown(83)){
      yRaqOponente += 10;
    }
  }
  
function bolinhaNaoFicaPresa(){
    if (XBolinha - raio < 0){
    XBolinha = 23
    }
}

}

